<div class="container">
    <div class="row justify-content-center">
        <div class="group col-sm-100">
            <div class="poster">
                <a href="courses/reverse_shell_doc" style="text-decoration:none">
                    <div class="card mb-3" style="width: 900px; background-color: rgba(61, 72, 92); border : solid 0.5px white;">
                        <div class="row no-gutters">
                            <div class="col-lg-4">
                                <img src="images/RVS.png" class="img-fluid" width="180" height="100" >
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h6 class="card-subtitle mb-2" style="color: rgba(170, 170, 170)">Target system vulnerability</h6>
                                    <h5 class="card-title" style="color: white">Reverse shell</h5>
                                    <p class="card-text" style="color: white">Learn how to initiate a shell session and gain access to the victim’s computer.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>