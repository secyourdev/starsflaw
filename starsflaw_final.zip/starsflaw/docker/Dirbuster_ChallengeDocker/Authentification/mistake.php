<title>Erreur</title>


<ul class="nav">
                      <li>
                        <a href="register.php">Retour à l'inscription</a>
                      </li>
</ul>




<?php
echo "<p style='color : red ;'>Erreur de mot de passe il doit commencer par une lettre majuscule, se terminer par un chiffre, et faire + de 8 charactere</p>";
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

